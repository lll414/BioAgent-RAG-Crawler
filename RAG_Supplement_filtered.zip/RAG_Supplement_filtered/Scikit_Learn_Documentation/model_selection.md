# 3.Model selection and evaluation#

Source URL: https://scikit-learn.org/stable/model_selection.html
Date Scraped: 2025-12-11

---

* [User Guide](user_guide.html)
* 3. Model selection and evaluation

* [3.1. Cross-validation: evaluating estimator performance](modules/cross_validation.html)
  + [3.1.1. Computing cross-validated metrics](modules/cross_validation.html#computing-cross-validated-metrics)
  + [3.1.2. Cross validation iterators](modules/cross_validation.html#cross-validation-iterators)
  + [3.1.3. A note on shuffling](modules/cross_validation.html#a-note-on-shuffling)
  + [3.1.4. Cross validation and model selection](modules/cross_validation.html#cross-validation-and-model-selection)
  + [3.1.5. Permutation test score](modules/cross_validation.html#permutation-test-score)
* [3.2. Tuning the hyper-parameters of an estimator](modules/grid_search.html)
  + [3.2.1. Exhaustive Grid Search](modules/grid_search.html#exhaustive-grid-search)
  + [3.2.2. Randomized Parameter Optimization](modules/grid_search.html#randomized-parameter-optimization)
  + [3.2.3. Searching for optimal parameters with successive halving](modules/grid_search.html#searching-for-optimal-parameters-with-successive-halving)
  + [3.2.4. Tips for parameter search](modules/grid_search.html#tips-for-parameter-search)
  + [3.2.5. Alternatives to brute force parameter search](modules/grid_search.html#alternatives-to-brute-force-parameter-search)
* [3.3. Tuning the decision threshold for class prediction](modules/classification_threshold.html)
  + [3.3.1. Post-tuning the decision threshold](modules/classification_threshold.html#post-tuning-the-decision-threshold)
* [3.4. Metrics and scoring: quantifying the quality of predictions](modules/model_evaluation.html)
  + [3.4.1. Which scoring function should I use?](modules/model_evaluation.html#which-scoring-function-should-i-use)
  + [3.4.2. Scoring API overview](modules/model_evaluation.html#scoring-api-overview)
  + [3.4.3. The `scoring` parameter: defining model evaluation rules](modules/model_evaluation.html#the-scoring-parameter-defining-model-evaluation-rules)
  + [3.4.4. Classification metrics](modules/model_evaluation.html#classification-metrics)
  + [3.4.5. Multilabel ranking metrics](modules/model_evaluation.html#multilabel-ranking-metrics)
  + [3.4.6. Regression metrics](modules/model_evaluation.html#regression-metrics)
  + [3.4.7. Clustering metrics](modules/model_evaluation.html#clustering-metrics)
  + [3.4.8. Dummy estimators](modules/model_evaluation.html#dummy-estimators)
* [3.5. Validation curves: plotting scores to evaluate models](modules/learning_curve.html)
  + [3.5.1. Validation curve](modules/learning_curve.html#validation-curve)
  + [3.5.2. Learning curve](modules/learning_curve.html#learning-curve)

[previous

2.9. Neural network models (unsupervised)](modules/neural_networks_unsupervised.html "previous page")
[next

3.1. Cross-validation: evaluating estimator performance](modules/cross_validation.html "next page")

### This Page

* [Show Source](_sources/model_selection.rst.txt)
# 7.Dataset transformations#

Source URL: https://scikit-learn.org/stable/data_transforms.html
Date Scraped: 2025-12-11

---

* [User Guide](user_guide.html)
* 7. Dataset transformations

scikit-learn provides a library of transformers, which may clean (see
[Preprocessing data](modules/preprocessing.html#preprocessing)), reduce (see [Unsupervised dimensionality reduction](modules/unsupervised_reduction.html#data-reduction)), expand (see
[Kernel Approximation](modules/kernel_approximation.html#kernel-approximation)) or generate (see [Feature extraction](modules/feature_extraction.html#feature-extraction))
feature representations.

Like other estimators, these are represented by classes with a `fit` method,
which learns model parameters (e.g. mean and standard deviation for
normalization) from a training set, and a `transform` method which applies
this transformation model to unseen data. `fit_transform` may be more
convenient and efficient for modelling and transforming the training data
simultaneously.

Combining such transformers, either in parallel or series is covered in
[Pipelines and composite estimators](modules/compose.html#combining-estimators). [Pairwise metrics, Affinities and Kernels](modules/metrics.html#metrics) covers transforming feature
spaces into affinity matrices, while [Transforming the prediction target (y)](modules/preprocessing_targets.html#preprocessing-targets) considers
transformations of the target space (e.g. categorical labels) for use in
scikit-learn.

* [7.1. Pipelines and composite estimators](modules/compose.html)
  + [7.1.1. Pipeline: chaining estimators](modules/compose.html#pipeline-chaining-estimators)
  + [7.1.2. Transforming target in regression](modules/compose.html#transforming-target-in-regression)
  + [7.1.3. FeatureUnion: composite feature spaces](modules/compose.html#featureunion-composite-feature-spaces)
  + [7.1.4. ColumnTransformer for heterogeneous data](modules/compose.html#columntransformer-for-heterogeneous-data)
  + [7.1.5. Visualizing Composite Estimators](modules/compose.html#visualizing-composite-estimators)
* [7.2. Feature extraction](modules/feature_extraction.html)
  + [7.2.1. Loading features from dicts](modules/feature_extraction.html#loading-features-from-dicts)
  + [7.2.2. Feature hashing](modules/feature_extraction.html#feature-hashing)
  + [7.2.3. Text feature extraction](modules/feature_extraction.html#text-feature-extraction)
  + [7.2.4. Image feature extraction](modules/feature_extraction.html#image-feature-extraction)
* [7.3. Preprocessing data](modules/preprocessing.html)
  + [7.3.1. Standardization, or mean removal and variance scaling](modules/preprocessing.html#standardization-or-mean-removal-and-variance-scaling)
  + [7.3.2. Non-linear transformation](modules/preprocessing.html#non-linear-transformation)
  + [7.3.3. Normalization](modules/preprocessing.html#normalization)
  + [7.3.4. Encoding categorical features](modules/preprocessing.html#encoding-categorical-features)
  + [7.3.5. Discretization](modules/preprocessing.html#discretization)
  + [7.3.6. Imputation of missing values](modules/preprocessing.html#imputation-of-missing-values)
  + [7.3.7. Generating polynomial features](modules/preprocessing.html#generating-polynomial-features)
  + [7.3.8. Custom transformers](modules/preprocessing.html#custom-transformers)
* [7.4. Imputation of missing values](modules/impute.html)
  + [7.4.1. Univariate vs. Multivariate Imputation](modules/impute.html#univariate-vs-multivariate-imputation)
  + [7.4.2. Univariate feature imputation](modules/impute.html#univariate-feature-imputation)
  + [7.4.3. Multivariate feature imputation](modules/impute.html#multivariate-feature-imputation)
  + [7.4.4. Nearest neighbors imputation](modules/impute.html#nearest-neighbors-imputation)
  + [7.4.5. Keeping the number of features constant](modules/impute.html#keeping-the-number-of-features-constant)
  + [7.4.6. Marking imputed values](modules/impute.html#marking-imputed-values)
  + [7.4.7. Estimators that handle NaN values](modules/impute.html#estimators-that-handle-nan-values)
* [7.5. Unsupervised dimensionality reduction](modules/unsupervised_reduction.html)
  + [7.5.1. PCA: principal component analysis](modules/unsupervised_reduction.html#pca-principal-component-analysis)
  + [7.5.2. Random projections](modules/unsupervised_reduction.html#random-projections)
  + [7.5.3. Feature agglomeration](modules/unsupervised_reduction.html#feature-agglomeration)
* [7.6. Random Projection](modules/random_projection.html)
  + [7.6.1. The Johnson-Lindenstrauss lemma](modules/random_projection.html#the-johnson-lindenstrauss-lemma)
  + [7.6.2. Gaussian random projection](modules/random_projection.html#gaussian-random-projection)
  + [7.6.3. Sparse random projection](modules/random_projection.html#sparse-random-projection)
  + [7.6.4. Inverse Transform](modules/random_projection.html#inverse-transform)
* [7.7. Kernel Approximation](modules/kernel_approximation.html)
  + [7.7.1. Nystroem Method for Kernel Approximation](modules/kernel_approximation.html#nystroem-method-for-kernel-approximation)
  + [7.7.2. Radial Basis Function Kernel](modules/kernel_approximation.html#radial-basis-function-kernel)
  + [7.7.3. Additive Chi Squared Kernel](modules/kernel_approximation.html#additive-chi-squared-kernel)
  + [7.7.4. Skewed Chi Squared Kernel](modules/kernel_approximation.html#skewed-chi-squared-kernel)
  + [7.7.5. Polynomial Kernel Approximation via Tensor Sketch](modules/kernel_approximation.html#polynomial-kernel-approximation-via-tensor-sketch)
  + [7.7.6. Mathematical Details](modules/kernel_approximation.html#mathematical-details)
* [7.8. Pairwise metrics, Affinities and Kernels](modules/metrics.html)
  + [7.8.1. Cosine similarity](modules/metrics.html#cosine-similarity)
  + [7.8.2. Linear kernel](modules/metrics.html#linear-kernel)
  + [7.8.3. Polynomial kernel](modules/metrics.html#polynomial-kernel)
  + [7.8.4. Sigmoid kernel](modules/metrics.html#sigmoid-kernel)
  + [7.8.5. RBF kernel](modules/metrics.html#rbf-kernel)
  + [7.8.6. Laplacian kernel](modules/metrics.html#laplacian-kernel)
  + [7.8.7. Chi-squared kernel](modules/metrics.html#chi-squared-kernel)
* [7.9. Transforming the prediction target (`y`)](modules/preprocessing_targets.html)
  + [7.9.1. Label binarization](modules/preprocessing_targets.html#label-binarization)
  + [7.9.2. Label encoding](modules/preprocessing_targets.html#label-encoding)

[previous

6. Visualizations](visualizations.html "previous page")
[next

7.1. Pipelines and composite estimators](modules/compose.html "next page")

### This Page

* [Show Source](_sources/data_transforms.rst.txt)
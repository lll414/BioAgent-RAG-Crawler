# 2.Unsupervised learning#

Source URL: https://scikit-learn.org/stable/unsupervised_learning.html
Date Scraped: 2025-12-11

---

* [User Guide](user_guide.html)
* 2. Unsupervised learning

* [2.1. Gaussian mixture models](modules/mixture.html)
  + [2.1.1. Gaussian Mixture](modules/mixture.html#gaussian-mixture)
  + [2.1.2. Variational Bayesian Gaussian Mixture](modules/mixture.html#variational-bayesian-gaussian-mixture)
* [2.2. Manifold learning](modules/manifold.html)
  + [2.2.1. Introduction](modules/manifold.html#introduction)
  + [2.2.2. Isomap](modules/manifold.html#isomap)
  + [2.2.3. Locally Linear Embedding](modules/manifold.html#locally-linear-embedding)
  + [2.2.4. Modified Locally Linear Embedding](modules/manifold.html#modified-locally-linear-embedding)
  + [2.2.5. Hessian Eigenmapping](modules/manifold.html#hessian-eigenmapping)
  + [2.2.6. Spectral Embedding](modules/manifold.html#spectral-embedding)
  + [2.2.7. Local Tangent Space Alignment](modules/manifold.html#local-tangent-space-alignment)
  + [2.2.8. Multi-dimensional Scaling (MDS)](modules/manifold.html#multi-dimensional-scaling-mds)
  + [2.2.9. t-distributed Stochastic Neighbor Embedding (t-SNE)](modules/manifold.html#t-distributed-stochastic-neighbor-embedding-t-sne)
  + [2.2.10. Tips on practical use](modules/manifold.html#tips-on-practical-use)
* [2.3. Clustering](modules/clustering.html)
  + [2.3.1. Overview of clustering methods](modules/clustering.html#overview-of-clustering-methods)
  + [2.3.2. K-means](modules/clustering.html#k-means)
  + [2.3.3. Affinity Propagation](modules/clustering.html#affinity-propagation)
  + [2.3.4. Mean Shift](modules/clustering.html#mean-shift)
  + [2.3.5. Spectral clustering](modules/clustering.html#spectral-clustering)
  + [2.3.6. Hierarchical clustering](modules/clustering.html#hierarchical-clustering)
  + [2.3.7. DBSCAN](modules/clustering.html#dbscan)
  + [2.3.8. HDBSCAN](modules/clustering.html#hdbscan)
  + [2.3.9. OPTICS](modules/clustering.html#optics)
  + [2.3.10. BIRCH](modules/clustering.html#birch)
  + [2.3.11. Clustering performance evaluation](modules/clustering.html#clustering-performance-evaluation)
* [2.4. Biclustering](modules/biclustering.html)
  + [2.4.1. Spectral Co-Clustering](modules/biclustering.html#spectral-co-clustering)
  + [2.4.2. Spectral Biclustering](modules/biclustering.html#spectral-biclustering)
  + [2.4.3. Biclustering evaluation](modules/biclustering.html#biclustering-evaluation)
* [2.5. Decomposing signals in components (matrix factorization problems)](modules/decomposition.html)
  + [2.5.1. Principal component analysis (PCA)](modules/decomposition.html#principal-component-analysis-pca)
  + [2.5.2. Kernel Principal Component Analysis (kPCA)](modules/decomposition.html#kernel-principal-component-analysis-kpca)
  + [2.5.3. Truncated singular value decomposition and latent semantic analysis](modules/decomposition.html#truncated-singular-value-decomposition-and-latent-semantic-analysis)
  + [2.5.4. Dictionary Learning](modules/decomposition.html#dictionary-learning)
  + [2.5.5. Factor Analysis](modules/decomposition.html#factor-analysis)
  + [2.5.6. Independent component analysis (ICA)](modules/decomposition.html#independent-component-analysis-ica)
  + [2.5.7. Non-negative matrix factorization (NMF or NNMF)](modules/decomposition.html#non-negative-matrix-factorization-nmf-or-nnmf)
  + [2.5.8. Latent Dirichlet Allocation (LDA)](modules/decomposition.html#latent-dirichlet-allocation-lda)
* [2.6. Covariance estimation](modules/covariance.html)
  + [2.6.1. Empirical covariance](modules/covariance.html#empirical-covariance)
  + [2.6.2. Shrunk Covariance](modules/covariance.html#shrunk-covariance)
  + [2.6.3. Sparse inverse covariance](modules/covariance.html#sparse-inverse-covariance)
  + [2.6.4. Robust Covariance Estimation](modules/covariance.html#robust-covariance-estimation)
* [2.7. Novelty and Outlier Detection](modules/outlier_detection.html)
  + [2.7.1. Overview of outlier detection methods](modules/outlier_detection.html#overview-of-outlier-detection-methods)
  + [2.7.2. Novelty Detection](modules/outlier_detection.html#novelty-detection)
  + [2.7.3. Outlier Detection](modules/outlier_detection.html#id1)
  + [2.7.4. Novelty detection with Local Outlier Factor](modules/outlier_detection.html#novelty-detection-with-local-outlier-factor)
* [2.8. Density Estimation](modules/density.html)
  + [2.8.1. Density Estimation: Histograms](modules/density.html#density-estimation-histograms)
  + [2.8.2. Kernel Density Estimation](modules/density.html#kernel-density-estimation)
* [2.9. Neural network models (unsupervised)](modules/neural_networks_unsupervised.html)
  + [2.9.1. Restricted Boltzmann machines](modules/neural_networks_unsupervised.html#restricted-boltzmann-machines)

[previous

1.17. Neural network models (supervised)](modules/neural_networks_supervised.html "previous page")
[next

2.1. Gaussian mixture models](modules/mixture.html "next page")

### This Page

* [Show Source](_sources/unsupervised_learning.rst.txt)
# 14.External Resources, Videos and Talks#

Source URL: https://scikit-learn.org/stable/presentations.html
Date Scraped: 2025-12-11

---

* [User Guide](user_guide.html)
* 14. External Resources, Videos and Talks

## 14.1. The scikit-learn MOOC[#](#the-scikit-learn-mooc "Link to this heading")

If you are new to scikit-learn, or looking to strengthen your understanding,
we highly recommend the **scikit-learn MOOC (Massive Open Online Course)**.

The MOOC, created and maintained by some of the scikit-learn core-contributors,
is **free of charge** and is designed to help learners of all levels master
machine learning using scikit-learn. It covers topics
from the fundamental machine learning concepts to more advanced areas like
predictive modeling pipelines and model evaluation.

The course materials are available on the
[scikit-learn MOOC website](https://inria.github.io/scikit-learn-mooc/).

This course is also hosted on the [FUN platform](https://www.fun-mooc.fr/en/courses/machine-learning-python-scikit-learn/),
which additionally makes the content interactive without the need to install
anything, and gives access to a discussion forum.

The videos are available on the
[Inria Learning Lab channel](https://www.youtube.com/@inrialearninglab)
in a
[playlist](https://www.youtube.com/playlist?list=PL2okA_2qDJ-m44KooOI7x8tu85wr4ez4f).

## 14.2. Videos[#](#videos "Link to this heading")

* The [scikit-learn YouTube channel](https://www.youtube.com/@scikit-learn)
  features a
  [playlist](https://www.youtube.com/@scikit-learn/playlists)
  of videos
  showcasing talks by maintainers
  and community members.

## 14.3. New to Scientific Python?[#](#new-to-scientific-python "Link to this heading")

For those that are still new to the scientific Python ecosystem, we highly
recommend the [Python Scientific Lecture Notes](https://scipy-lectures.org). This will help you find your footing a
bit and will definitely improve your scikit-learn experience. A basic
understanding of NumPy arrays is recommended to make the most of scikit-learn.

## 14.4. External Tutorials[#](#external-tutorials "Link to this heading")

There are several online tutorials available which are geared toward
specific subject areas:

* [Machine Learning for NeuroImaging in Python](https://nilearn.github.io/)
* [Machine Learning for Astronomical Data Analysis](https://github.com/astroML/sklearn_tutorial)

[previous

13. Choosing the right estimator](machine_learning_map.html "previous page")
[next

API Reference](api/index.html "next page")

On this page

* [14.1. The scikit-learn MOOC](#the-scikit-learn-mooc)
* [14.2. Videos](#videos)
* [14.3. New to Scientific Python?](#new-to-scientific-python)
* [14.4. External Tutorials](#external-tutorials)

### This Page

* [Show Source](_sources/presentations.rst.txt)
# 7.9.Transforming the prediction target (y)#

Source URL: https://scikit-learn.org/stable/modules/preprocessing_targets.html
Date Scraped: 2025-12-11

---

* [User Guide](../user_guide.html)
* [7. Dataset transformations](../data_transforms.html)
* 7.9. Transforming the prediction target (`y`)

These are transformers that are not intended to be used on features, only on
supervised learning targets. See also [Transforming target in regression](compose.html#transformed-target-regressor) if
you want to transform the prediction target for learning, but evaluate the
model in the original (untransformed) space.

## 7.9.1. Label binarization[#](#label-binarization "Link to this heading")

### 7.9.1.1. LabelBinarizer[#](#labelbinarizer "Link to this heading")

[`LabelBinarizer`](generated/sklearn.preprocessing.LabelBinarizer.html#sklearn.preprocessing.LabelBinarizer "sklearn.preprocessing.LabelBinarizer") is a utility class to help create a [label
indicator matrix](../glossary.html#term-label-indicator-matrix) from a list of [multiclass](../glossary.html#term-multiclass) labels:

```
>>> from sklearn import preprocessing
>>> lb = preprocessing.LabelBinarizer()
>>> lb.fit([1, 2, 6, 4, 2])
LabelBinarizer()
>>> lb.classes_
array([1, 2, 4, 6])
>>> lb.transform([1, 6])
array([[1, 0, 0, 0],
       [0, 0, 0, 1]])
```

Using this format can enable multiclass classification in estimators
that support the label indicator matrix format.

Warning

LabelBinarizer is not needed if you are using an estimator that
already supports [multiclass](../glossary.html#term-multiclass) data.

For more information about multiclass classification, refer to
[Multiclass classification](multiclass.html#multiclass-classification).

### 7.9.1.2. MultiLabelBinarizer[#](#multilabelbinarizer "Link to this heading")

In [multilabel](../glossary.html#term-multilabel) learning, the joint set of binary classification tasks is
expressed with a label binary indicator array: each sample is one row of a 2d
array of shape (n\_samples, n\_classes) with binary values where the one, i.e. the
non zero elements, corresponds to the subset of labels for that sample. An array
such as `np.array([[1, 0, 0], [0, 1, 1], [0, 0, 0]])` represents label 0 in the
first sample, labels 1 and 2 in the second sample, and no labels in the third
sample.

Producing multilabel data as a list of sets of labels may be more intuitive.
The [`MultiLabelBinarizer`](generated/sklearn.preprocessing.MultiLabelBinarizer.html#sklearn.preprocessing.MultiLabelBinarizer "sklearn.preprocessing.MultiLabelBinarizer")
transformer can be used to convert between a collection of collections of
labels and the indicator format:

```
>>> from sklearn.preprocessing import MultiLabelBinarizer
>>> y = [[2, 3, 4], [2], [0, 1, 3], [0, 1, 2, 3, 4], [0, 1, 2]]
>>> MultiLabelBinarizer().fit_transform(y)
array([[0, 0, 1, 1, 1],
       [0, 0, 1, 0, 0],
       [1, 1, 0, 1, 0],
       [1, 1, 1, 1, 1],
       [1, 1, 1, 0, 0]])
```

For more information about multilabel classification, refer to
[Multilabel classification](multiclass.html#multilabel-classification).

## 7.9.2. Label encoding[#](#label-encoding "Link to this heading")

[`LabelEncoder`](generated/sklearn.preprocessing.LabelEncoder.html#sklearn.preprocessing.LabelEncoder "sklearn.preprocessing.LabelEncoder") is a utility class to help normalize labels such that
they contain only values between 0 and n\_classes-1. This is sometimes useful
for writing efficient Cython routines. [`LabelEncoder`](generated/sklearn.preprocessing.LabelEncoder.html#sklearn.preprocessing.LabelEncoder "sklearn.preprocessing.LabelEncoder") can be used as
follows:

```
>>> from sklearn import preprocessing
>>> le = preprocessing.LabelEncoder()
>>> le.fit([1, 2, 2, 6])
LabelEncoder()
>>> le.classes_
array([1, 2, 6])
>>> le.transform([1, 1, 2, 6])
array([0, 0, 1, 2])
>>> le.inverse_transform([0, 0, 1, 2])
array([1, 1, 2, 6])
```

It can also be used to transform non-numerical labels (as long as they are
hashable and comparable) to numerical labels:

```
>>> le = preprocessing.LabelEncoder()
>>> le.fit(["paris", "paris", "tokyo", "amsterdam"])
LabelEncoder()
>>> list(le.classes_)
[np.str_('amsterdam'), np.str_('paris'), np.str_('tokyo')]
>>> le.transform(["tokyo", "tokyo", "paris"])
array([2, 2, 1])
>>> list(le.inverse_transform([2, 2, 1]))
[np.str_('tokyo'), np.str_('tokyo'), np.str_('paris')]
```

[previous

7.8. Pairwise metrics, Affinities and Kernels](metrics.html "previous page")
[next

8. Dataset loading utilities](../datasets.html "next page")

On this page

* [7.9.1. Label binarization](#label-binarization)
  + [7.9.1.1. LabelBinarizer](#labelbinarizer)
  + [7.9.1.2. MultiLabelBinarizer](#multilabelbinarizer)
* [7.9.2. Label encoding](#label-encoding)

### This Page

* [Show Source](../_sources/modules/preprocessing_targets.rst.txt)